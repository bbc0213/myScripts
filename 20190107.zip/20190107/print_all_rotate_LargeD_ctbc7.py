import numpy as np
import skimage.io
import matplotlib.pyplot as plt
import skimage.segmentation
import model as modellib
import xml.etree.ElementTree as ET
import utils
from model import log
import os
import pandas as pd

import sys
import random
import math
import re
import time
import cv2
import matplotlib


import scipy
from skimage import transform
from skimage import img_as_float
from skimage import img_as_ubyte
from skimage import img_as_uint

import coco41_aug_L16 as CTBC
import tensorflow as tf

FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_string('bank', None, 'The bank id of the training model.') 
tf.app.flags.DEFINE_string('model_path', None, 'The path of the training model.')  
tf.app.flags.DEFINE_string('test_dir', None, 'The directory of the testing images.')  
tf.app.flags.DEFINE_string('plot_dir', 'evaluation/ploting_result', 'The directory of the ploting  images.')

if not FLAGS.bank:
    raise ValueError('You must supply the bank id of the training model with --bank')

if not FLAGS.model_path:
    raise ValueError('You must supply the path of the training model with --model_path')

if not FLAGS.test_dir:
    raise ValueError('You must supply the directory of the testing images with --test_dir')

bank_name = FLAGS.bank
model_path = FLAGS.model_path
DIR_TEST = FLAGS.test_dir



plt_dir=os.path.join(FLAGS.plot_dir,'fields_'+bank_name)	
if not os.path.isdir(plt_dir):
    os.makedirs(plt_dir)




dataset = CTBC.CTBCDataset()
dataset.load_data(DIR_TEST, mode='all', bank_name=bank_name)#real with ground truth
#dataset.load_data(DIR_TEST, mode='test', bank_name=bank_name)#
#dataset.load_data2(DIR_TEST, mode='train')#real without ground truth
dataset.prepare()








image_ids = dataset.image_ids#[8:]


class InferenceConfig(CTBC.CTBCConfig):
    GPU_COUNT = 1
    IMAGES_PER_GPU = 1
    RPN_NMS_THRESHOLD = 0.7
    DETECTION_MAX_INSTANCES = 300
    #RPN_NMS_THRESHOLD = 0.9
    #DETECTION_MAX_INSTANCES = 400
    #RPN_ANCHOR_RATIOS = [0.5, 1, 2]
    RPN_ANCHOR_RATIOS = [0.333333, 0.5, 1, 2, 3]    
    DETECTION_MIN_CONFIDENCE = 0.5#0.1
    RPN_NMS_THRESHOLD = 0.9
    DETECTION_NMS_THRESHOLD = 0.5#0.9
    
inference_config = InferenceConfig()
inference_config.extractor = 'res50' #res50,res101,vgg19,incepResV2,incepV3

inference_config.fpn = True
inference_config = dataset.load_data_modifing_configure(inference_config)
inference_config.display()

# Recreate the model in inference mode
model = modellib.MaskRCNN(mode="inference", config=inference_config, model_dir=model_path)

print("Loading weights from ", model_path)
model.load_weights(model_path, by_name=True)
print("Loading finish")




def ocr_txt(image_id,image,nms_bboxes,nms_class):

    #allocating the rows and columns by sorting the (x,y) of the fields
    ii = np.lexsort((nms_bboxes[:,1],nms_bboxes[:,0]))		
    first_indx=ii[0]
    h5=(nms_bboxes[first_indx,2]-nms_bboxes[first_indx,0])*0.5	
    jj=[]
    y_ref=nms_bboxes[first_indx,0]
    jj.append([])
    count_row = 0	
    jj[count_row].append(nms_bboxes[ii[0]])	
    for m in range(1,len(nms_scores)) :
        if	abs(nms_bboxes[ii[m],0]-y_ref) < h5 :
            jj[count_row].append(nms_bboxes[ii[m]])
        else :
            jj.append([])
            count_row += 1
            jj[count_row].append(nms_bboxes[ii[m]])	
            y_ref=nms_bboxes[ii[m],0]
			
    height, width = image.shape[:2]
    fname = os.path.join(plt_dir,str(image_id)+'.txt')
    f = open(fname, 'w')
    print('ctbc',file=f)	
    for i in range(0,len(jj)) :
        q=np.asarray(jj[i])
        qq=np.argsort(q[:,1])		
        for j in range(0,len(jj[i])) :

            y1 = int(jj[i][qq[j]][0])	
            x1 = int(jj[i][qq[j]][1])
            y2 = int(jj[i][qq[j]][2])	
            x2 = int(jj[i][qq[j]][3])
            print('({},{},{},{})'.format(y1,x1,y2,x2),file=f,end='')			
            #mask = np.zeros((height, width,3))			
            #mask[y1:y2,x1:x2,:] = image[y1:y2,x1:x2,:]
            #fname = os.path.join(image_dir,str(i)+'_'+str(j)+'.png')		
            #scipy.misc.imsave(fname, mask)	
            if j < len(jj[i])-1 :
                print(' ',file=f,end='')			            
        print('\n',file=f,end='')



def precision_at(threshold, iou):
    matches = iou > threshold
    true_positives = np.sum(matches, axis=1) == 1   # Correct objects
    #print('true_positives{}'.format(true_positives))
    false_positives = np.sum(matches, axis=0) == 0  # Missed objects
    false_negatives = np.sum(matches, axis=1) == 0  # Extra objects
    tp, fp, fn = np.sum(true_positives), np.sum(false_positives), np.sum(false_negatives)
    return tp, fp, fn




        


def ploting_predict(image_id,image,nms_bboxes,nms_scores,nms_class):

	#ploting the predicted fields
    fname = os.path.join(plt_dir,'score.txt')		
    np.savetxt(fname,nms_scores,fmt='%.2f')
    fname = os.path.join(plt_dir,'bbox.txt')	
    np.savetxt(fname,nms_bboxes)
	
    height, width = image.shape[:2]		

    mask_s = np.zeros((height, width,3))
    for c_i in range(1,inference_config.NUM_CLASSES) :
        mask_ci = np.zeros((height, width,3))	
        for m in range(0,len(nms_scores)) :
            if nms_class[m] == c_i :

		
                #rois: [N, (y1, x1, y2, x2)]
                y1 = int(nms_bboxes[m][0])	
                x1 = int(nms_bboxes[m][1])
                y2 = int(nms_bboxes[m][2])	
                x2 = int(nms_bboxes[m][3])	

                mask_ci[y1:y2,x1:x2,:] += image[y1:y2,x1:x2,:]
                mask_s[y1:y2,x1:x2,:] += image[y1:y2,x1:x2,:]
        #print bbox image
        fname = os.path.join(plt_dir,str(image_id)+'_'+str(c_i)+'.jpg')
        cv2.imwrite(fname, mask_ci)			
	
    fname = os.path.join(plt_dir,str(image_id)+'_s.jpg')		
    cv2.imwrite(fname, mask_s)
    fname = os.path.join(plt_dir,str(image_id)+'.jpg')		
    cv2.imwrite(fname, image)
	




def ploting_ground_truth(image_id,image,labels_mask):
	
    #ploting the ground truth masks
    height, width = image.shape[:2]		
    mask_s3 = np.zeros((height, width,3))	
    for m in range(0,labels_mask.shape[-1]) :	
        row, col = np.where(labels_mask[...,m] > 0)[:2]		
        mask_s3[row, col,:] += image[row, col,:]
			
    fname = os.path.join(plt_dir,str(image_id)+'_gt.jpg')		
    cv2.imwrite(fname, mask_s3)	



	
	
def cal_iou(image,labels_mask,nms_masks_bboxes):

    height, width = image.shape[:2]
    labels = np.zeros((height, width), np.uint16)	
    for index in range(0, labels_mask.shape[-1]):
        labels[labels_mask[...,index] > 0] = index + 1
		
    y_pred = np.zeros((height, width), np.uint16)		
    for index in range(0,nms_masks_bboxes.shape[-1]):
        y_pred[nms_masks_bboxes[...,index] > 0] = index + 1		
		
    true_objects = len(np.unique(labels))
    pred_objects = len(np.unique(y_pred))	
		

    intersection = np.histogram2d(labels.flatten(), y_pred.flatten(), bins=(true_objects, pred_objects))[0]
    #print('intersection{}'.format(intersection.shape))

    # Compute areas (needed for finding the union between all objects)
    area_true = np.histogram(labels, bins = true_objects)[0]
    area_pred = np.histogram(y_pred, bins = pred_objects)[0]
    #print('area_true{}'.format(area_true.shape))
    #print('area_true{}'.format(area_true))
    area_true = np.expand_dims(area_true, -1)
    area_pred = np.expand_dims(area_pred, 0)

    # Compute union
    union = area_true + area_pred - intersection

    # Exclude background from the analysis
    intersection = intersection[1:,1:]
    union = union[1:,1:]
    union[union == 0] = 1e-9

    # Compute the intersection over union
    iou = intersection / union

    return iou







def bboxes_to_mask(image,nms_bboxes):
	
    height, width = image.shape[:2]		
    num_bboxes = len(nms_scores)
    masks = np.zeros((height, width,num_bboxes))
    ones = np.ones((height, width))	
    for m in range(0,len(nms_scores)) :
		
        #rois: [N, (y1, x1, y2, x2)]
        y1 = int(nms_bboxes[m][0])	
        x1 = int(nms_bboxes[m][1])
        y2 = int(nms_bboxes[m][2])	
        x2 = int(nms_bboxes[m][3])	

        masks[y1:y2,x1:x2,m] = ones[y1:y2,x1:x2]

    return masks
	
        

		

		

threshold=0.5
prec_all = []
reca_all = []
print("Predicting data")
total_time=0
prec05 =[]
prec06 =[]
prec07 =[]
prec08 =[]
prec09 =[]
reca05 =[]
reca06 =[]
reca07 =[]
reca08 =[]
reca09 =[]


for image_id in image_ids :

    tStart = time.time()	
    print('image_id:{}'.format(image_id))
		
    image = dataset.load_image(image_id)	
    #print('image:h={},w={}'.format(image.shape[0],image.shape[1]))	
	
  
    # Run object detection
    results = model.detect([image], verbose=0)
    r = results[0]
    
    #for m in range(r['masks'].shape[2]) :
        #scipy.ndimage.morphology.binary_fill_holes(r['masks'][...,m]).astype(int)
    
        # each angle mask do non_max_suppression_masks individually   
    #nms_keep = utils.non_max_suppression_masks(r['masks'],r["scores"],threshold)
        

    nms_scores = r['scores']#[nms_keep]
    nms_masks = r['masks']#[...,nms_keep]
    nms_bboxes = r['rois']#[nms_keep,:]
    nms_class = r['class_ids']	
    print('{}:nms_scores:{},nms_masks:{},nms_bboxes:{},nms_class:{}'.format(image_id,nms_scores.shape,nms_masks.shape,nms_bboxes.shape,nms_class.shape))
	
    tEnd = time.time()
    total_time+=(tEnd-tStart)				
    print('img{}:cost {} sec,total time:{} sec'.format(image_id,(tEnd-tStart),total_time))

	

    #ocr_txt(image_id,image,nms_bboxes,nms_class)
    nms_masks_bboxes = bboxes_to_mask(image,nms_bboxes)
	
    ploting_predict(image_id,image,nms_bboxes,nms_scores,nms_class)	


    #evaluating precision
	
    labels_mask, labels_class_ids = dataset.load_mask(image_id)
	
    ploting_ground_truth(image_id,image,labels_mask)
	
    iou = cal_iou(image,labels_mask,nms_masks_bboxes)

	# Loop over IoU thresholds
    prec = []
    reca = []	
    print("Thresh\tTP\tFP\tFN\tPrec.\tReca.")
    for t in np.arange(0.5, 1.05, 0.1):
        tp, fp, fn = precision_at(t, iou)
		
        if 	np.round((tp + fp), 2) == 0.0 :	
            precision = 0.0	
        else :			
            precision = tp / (tp + fp)
			
        if 	np.round((tp + fn), 2) == 0.0 :	
            recall = 0.0
        else :			
            recall = tp / (tp + fn)	
			
        print("{:1.3f}\t{}\t{}\t{}\t{:1.3f}\t{:1.3f}".format(t, tp, fp, fn, precision, recall))
        prec.append(precision)
        reca.append(recall)		
        tt = np.round(t, 2)
        if tt==0.5:
            #print('t=0.5:{}'.format(tt))
            prec05.append(precision)
            reca05.append(recall)			
        if tt==0.6:
            #print('t=0.6:{}'.format(tt))
            prec06.append(precision)
            reca06.append(recall)			
        if tt==0.7:
            #print('t=0.7:{}'.format(tt))
            prec07.append(precision)
            reca07.append(recall)			
        if tt==0.8:
            #print('t=0.8:{}'.format(tt))		
            prec08.append(precision)
            reca08.append(recall)			
        if tt==0.9:
            #print('t=0.9:{}'.format(tt))		
            prec09.append(precision)
            reca09.append(recall)			






    print("AP\t-\t-\t-\t{:1.3f}\t{:1.3f}".format(np.mean(prec),np.mean(reca)))
    prec_all.append(np.mean(prec))
    reca_all.append(np.mean(reca))	
print("mAP\t-\t-\t-\t{:1.3f}\t{:1.3f}".format(np.mean(prec_all),np.mean(reca_all)))
print('len prec:{}'.format(len(prec05)))
print('*************IOU=0.5************{:1.3f}\t{:1.3f}'.format(np.mean(prec05),np.mean(reca05)))
print('*************IOU=0.6************{:1.3f}\t{:1.3f}'.format(np.mean(prec06),np.mean(reca06)))
print('*************IOU=0.7************{:1.3f}\t{:1.3f}'.format(np.mean(prec07),np.mean(reca07)))
print('*************IOU=0.8************{:1.3f}\t{:1.3f}'.format(np.mean(prec08),np.mean(reca08)))
print('*************IOU=0.9************{:1.3f}\t{:1.3f}'.format(np.mean(prec09),np.mean(reca09)))

data3 = {'IoU' : [0.5, 0.6, 0.7, 0.8, 0.9],
    'Precision' : [np.round(np.mean(prec05), 2), np.round(np.mean(prec06), 2), np.round(np.mean(prec07), 2), np.round(np.mean(prec08), 2), np.round(np.mean(prec09), 2)],
    'Recall' : [np.round(np.mean(reca05), 2),np.round(np.mean(reca06), 2),np.round(np.mean(reca07), 2),np.round(np.mean(reca08), 2),np.round(np.mean(reca09), 2)]}




df = pd.DataFrame(data3)

eval_log_dir=os.path.join('evaluation','log')
if not os.path.isdir(eval_log_dir):
    os.makedirs(eval_log_dir)
fname=model_path.split('/')[-2]
fname=os.path.join(eval_log_dir,fname+'.xlsx')
writer = pd.ExcelWriter(fname)
df.to_excel(writer,'Sheet1')
writer.save()
	
#df.to_csv(fname, index=False)
'''
for pre_i in np.arange(0.0, 1.0, 0.1) :
    img_tmp = []
    for img_i in image_ids :
        if (prec05[img_i]>= np.round(pre_i, 2)) and (prec05[img_i]< np.round(pre_i+0.1, 2)):            
            img_tmp.append(img_i)
    print('{:0.2f},{:0.2f},count:{},ratio:{:0.2f},img_id:({})'.format(np.round(pre_i+0.1, 2),np.round(pre_i, 2),len(img_tmp),len(img_tmp)/len(prec05),img_tmp))
'''



