import numpy as np
import skimage.io
import matplotlib.pyplot as plt
import skimage.segmentation
import model as modellib

import utils
from model import log
import os
import pandas as pd

import sys
import random
import math
import re
import time
import cv2
import matplotlib


import scipy
from skimage import transform
from skimage import img_as_float
from skimage import img_as_ubyte
from skimage import img_as_uint

from PIL import Image 
import tensorflow as tf

import coco41_page19 as CTBC

#from data_table import page 
#bank_id = page.bank_id

FLAGS = tf.app.flags.FLAGS

tf.app.flags.DEFINE_string('model_path', None, 'The path of the training model.')  
tf.app.flags.DEFINE_string('test_dir', None, 'The directory of the testing images.')  
tf.app.flags.DEFINE_string('plot_dir', 'evaluation/ploting_result', 'The directory of the ploting  images.')
tf.app.flags.DEFINE_string('train_dir', None, 'The directory of the testing images.')




if not FLAGS.model_path:
    raise ValueError('You must supply the path of the training model with --model_path')

if not FLAGS.test_dir:
    raise ValueError('You must supply the directory of the testing images with --test_dir')

if not FLAGS.train_dir:
    raise ValueError('You must supply the directory of the training images with --train_dir')




model_path = FLAGS.model_path
DIR_TEST = FLAGS.test_dir
DIR_TRAIN = FLAGS.train_dir

plt_dir=os.path.join(FLAGS.plot_dir,'page_results')


if not os.path.isdir(plt_dir):
    os.makedirs(plt_dir)





#for page detection
dataset = CTBC.CTBCDataset()
dataset.load_data_evaluate(test_dataset_path=DIR_TEST,train_dataset_path=DIR_TRAIN,mode='test')

#dataset.load_data2(CTBC_DIR_TEST, mode='test')
dataset.prepare()
 


image_ids = dataset.image_ids#[:11]
print('len(image_ids)'.format(len(image_ids)))

class InferenceConfig(CTBC.CTBCConfig):
    GPU_COUNT = 1
    IMAGES_PER_GPU = 1
    RPN_NMS_THRESHOLD = 0.7
    DETECTION_MAX_INSTANCES = 300
    #RPN_NMS_THRESHOLD = 0.9
    #DETECTION_MAX_INSTANCES = 400
    #RPN_ANCHOR_RATIOS = [0.5, 1, 2]
    RPN_ANCHOR_RATIOS = [0.333333, 0.5, 1, 2, 3]    
    DETECTION_MIN_CONFIDENCE = 0.7#0.9
    RPN_NMS_THRESHOLD = 0.5
    DETECTION_NMS_THRESHOLD = 0.5
    
inference_config = InferenceConfig()
inference_config.extractor = 'res50' #res50,res101,vgg19,incepResV2,incepV3
inference_config = dataset.load_data_modifing_configure(inference_config)

inference_config.fpn = True


inference_config.display()

# Recreate the model in inference mode
model = modellib.MaskRCNN(mode="inference", 
                          config=inference_config,
                          model_dir=model_path)

print("Loading weights from ", model_path)
model.load_weights(model_path, by_name=True)
print("Loading finish")


true_positives_085 = np.zeros((len(dataset.bank_id),), dtype=int)
false_positives_085 = np.zeros((len(dataset.bank_id),), dtype=int)
false_negatives_085 = np.zeros((len(dataset.bank_id),), dtype=int)
true_positives_090 = np.zeros((len(dataset.bank_id),), dtype=int)
false_positives_090 = np.zeros((len(dataset.bank_id),), dtype=int)
false_negatives_090 = np.zeros((len(dataset.bank_id),), dtype=int)
true_positives_095 = np.zeros((len(dataset.bank_id),), dtype=int)
false_positives_095 = np.zeros((len(dataset.bank_id),), dtype=int)
false_negatives_095 = np.zeros((len(dataset.bank_id),), dtype=int)
groundTruth_num = np.zeros((len(dataset.bank_id),), dtype=int)
def precision_at(threshold, iou,labels_class,pred_class):
    matches = iou > threshold
    true_positives_count = 0
    false_positives_count = 0
    false_negatives_count = 0
	
    for i in range(matches.shape[0]):#gt_num
        tag1=0
        groundTruth_num[labels_class[i]] += 1		
        for j in range(matches.shape[1]):#pred_num
            if (matches[i][j]) and (labels_class[i] == pred_class[j]):
                true_positives_count += 1
                tag1 += 1
                if np.round(threshold,2) == 0.85 :
                    true_positives_085[labels_class[i]] += 1
                if np.round(threshold,2) == 0.9 :
                    true_positives_090[labels_class[i]] += 1
                if np.round(threshold,2) == 0.95 :
                    true_positives_095[labels_class[i]] += 1
					
        if tag1 == 0:
            false_negatives_count += 1
            if np.round(threshold,2) == 0.85 :			
                false_negatives_085[labels_class[i]] += 1
            if np.round(threshold,2) == 0.9 :			
                false_negatives_090[labels_class[i]] += 1
            if np.round(threshold,2) == 0.95 :			
                false_negatives_095[labels_class[i]] += 1
				
    for j in range(matches.shape[1]):#pred_num
        tag1=0	
        for i in range(matches.shape[0]):#gt_num
            if (matches[i][j]) and (labels_class[i] == pred_class[j]):
                tag1 += 1
        if tag1 == 0:
            false_positives_count += 1				
            if np.round(threshold,2) == 0.85 :			
                false_positives_085[labels_class[i]] += 1
            if np.round(threshold,2) == 0.9 :			
                false_positives_090[labels_class[i]] += 1
            if np.round(threshold,2) == 0.95 :			
                false_positives_095[labels_class[i]] += 1			

    true_positives = np.sum(matches, axis=1) == 1   # Correct objects
    #print('true_positives:{},{},{}'.format(true_positives.shape,true_positives,np.sum(matches, axis=1)))
    false_positives = np.sum(matches, axis=0) == 0  # Missed objects
    #print('false_positives:{},{},{}'.format(false_positives.shape,false_positives,np.sum(matches, axis=0)))	
    false_negatives = np.sum(matches, axis=1) == 0  # Extra objects
    #print('false_negatives:{},{},{}'.format(false_negatives.shape,false_negatives,np.sum(matches, axis=1)))	
    tp, fp, fn = np.sum(true_positives), np.sum(false_positives), np.sum(false_negatives)
    #if (tp!=true_positives_count) or (fp!=false_positives_count) or (fn!=false_negatives_count) :
        #print('Error*:({},{}),({},{}),({},{})'.format(tp,true_positives_count, fp,false_positives_count, fn,false_negatives_count))		
    #return tp, fp, fn
    return true_positives_count, false_positives_count, false_negatives_count



        
        
      

	  

	  
	  
def ploting_predict(image_id,image,nms_bboxes,nms_masks,nms_scores):
	  
    for m in range(len(nms_scores)) :
		
        height, width = image.shape[:2]		

        mask_2 = np.zeros((height, width,3))
        mask_4 = np.zeros((height, width,3))
		
        row, col = np.where(nms_masks[...,m] > 0)[:2]		
        mask_2[row, col,:] = image[row, col,:]
		
        #rois: [N, (y1, x1, y2, x2)]
        y1 = int(nms_bboxes[m][0])	
        x1 = int(nms_bboxes[m][1])
        y2 = int(nms_bboxes[m][2])	
        x2 = int(nms_bboxes[m][3])	
        #print('{}:({},{},{},{})'.format(j,y1,x1,y2,x2))			

        mask_4[y1:y2,x1:x2,:] = image[y1:y2,x1:x2,:]

        fname = os.path.join(plt_dir,str(image_id)+'_m_'+str(m)+'.jpg')		
        cv2.imwrite(fname, mask_2)	
	
        #fname = os.path.join(plt_dir,str(image_id)+'_b_'+str(m)+'.jpg')		
        #cv2.imwrite(fname, mask_4)
		
    fname = os.path.join(plt_dir,str(image_id)+'.jpg')		
    cv2.imwrite(fname, image)


	
	
	
def ploting_ground_truth(image_id,image,labels_mask):
	
    #ploting the ground truth masks
    height, width = image.shape[:2]		
	
    for m in range(0,labels_mask.shape[-1]) :
        mask_3 = np.zeros((height, width,3))	
        row, col = np.where(labels_mask[...,m] > 0)[:2]		
        mask_3[row, col,:] = image[row, col,:]
			
        fname = os.path.join(plt_dir,str(image_id)+'_gt_'+str(m)+'.jpg')		
        cv2.imwrite(fname, mask_3)
		
    fname = os.path.join(plt_dir,str(image_id)+'.jpg')		
    cv2.imwrite(fname, image)
	  






def cal_iou(image,labels_mask,pred_mask):

    height, width = image.shape[:2]
    labels = np.zeros((height, width), np.uint16)	
    for index in range(0, labels_mask.shape[-1]):
        labels[labels_mask[...,index] > 0] = index + 1
		
    y_pred = np.zeros((height, width), np.uint16)		
    for index in range(0,pred_mask.shape[-1]):
        y_pred[pred_mask[...,index] > 0] = index + 1		
		
    true_objects = len(np.unique(labels))
    pred_objects = len(np.unique(y_pred))	
		

    intersection = np.histogram2d(labels.flatten(), y_pred.flatten(), bins=(true_objects, pred_objects))[0]
    #print('intersection:{},{}'.format(intersection.shape,intersection))

    # Compute areas (needed for finding the union between all objects)
    area_true = np.histogram(labels, bins = true_objects)[0]
    area_pred = np.histogram(y_pred, bins = pred_objects)[0]
    #print('area_true{}'.format(area_true.shape))
    #print('area_true{}'.format(area_true))
    area_true = np.expand_dims(area_true, -1)
    area_pred = np.expand_dims(area_pred, 0)

    # Compute union
    union = area_true + area_pred - intersection

    # Exclude background from the analysis
    intersection = intersection[1:,1:]
    union = union[1:,1:]
    union[union == 0] = 1e-9

    # Compute the intersection over union
    iou = intersection / union
    #print('*iou.shape:{},{}'.format(iou.shape,iou))
    return iou



	  

	  
	  
	  
	  
threshold=0.5
prec_all = []
reca_all = []
print("Predicting data")
total_time=0

prec85 =[]
prec90 =[]
prec95 =[]
reca85 =[]
reca90 =[]
reca95 =[]

for image_id in image_ids :

    prec = []
    reca = []
    info=dataset.image_info[image_id]
    print('image_id:{},tif:{},frame:{},xml:{}'.format(image_id,info['tif_id'], info['frame_id'],info['xml_path']))
		
    image_o = dataset.load_image_evaluate(image_id)
    labels_mask_o, labels_class_ids = dataset.load_mask_evaluate(image_id)

    for ang_i in range(4):
        tStart = time.time()

        image = np.rot90(image_o,ang_i)		
        # Run object detection
        results = model.detect([image], verbose=0)
        r = results[0]
 

        nms_scores = r['scores']#[nms_keep]
        nms_masks = r['masks']#[...,nms_keep]
        nms_bboxes = r['rois']#[nms_keep,:]
        nms_class = r['class_ids']
        print('{}_{}:nms_scores:{},nms_masks:{},nms_bboxes:{},nms_class:{}'.format(image_id,ang_i,nms_scores,nms_masks.shape,nms_bboxes.shape,nms_class.shape))
        tEnd = time.time()
        total_time+=(tEnd-tStart)	
        print('{}_{}:cost {} sec,total time:{}'.format(image_id,ang_i,(tEnd-tStart),total_time))	


        labels_mask = np.rot90(labels_mask_o,ang_i)		
        print('class:predict:{} ,gt:{}'.format(nms_class,labels_class_ids))	
	
        #ploting_predict(image_id,image,nms_bboxes,nms_masks,nms_scores)
        #ploting_ground_truth(image_id,image,labels_mask)
		
        iou = cal_iou(image,labels_mask,nms_masks)		
	
		
	    # Loop over IoU thresholds
	
        print("Thresh\tTP\tFP\tFN\tPrec.\tReca.")
        for t in np.arange(0.85, 0.99, 0.05):
            tp, fp, fn = precision_at(t, iou,labels_class_ids,nms_class)
		
            if 	np.round((tp + fp), 2) == 0.0 :	
                precision = 0.0	
            else :			
                precision = tp / (tp + fp)
			
            if 	np.round((tp + fn), 2) == 0.0 :	
                recall = 0.0
            else :			
                recall = tp / (tp + fn)

	
			
            print("{:1.3f}\t{}\t{}\t{}\t{:1.3f}\t{:1.3f}".format(t, tp, fp, fn, precision, recall))
            prec.append(precision)
            reca.append(recall)		
            tt = np.round(t, 2)
            if tt==0.85:
                #print('t=0.85:{}'.format(tt))
                prec85.append(precision)
                reca85.append(recall)			
            if tt==0.9:
                #print('t=0.9:{}'.format(tt))
                prec90.append(precision)
                reca90.append(recall)			
            if tt==0.95:
                #print('t=0.95:{}'.format(tt))
                prec95.append(precision)
                reca95.append(recall)			
	


        print("AP\t-\t-\t-\t{:1.3f}\t{:1.3f}".format(np.mean(prec),np.mean(reca)))
        prec_all.append(np.mean(prec))
        reca_all.append(np.mean(reca))	
print("mAP\t-\t-\t-\t{:1.3f}\t{:1.3f}".format(np.mean(prec_all),np.mean(reca_all)))
print('len prec:{}'.format(len(prec85)))
print('*************IOU=0.85***********{:1.3f}\t{:1.3f}'.format(np.mean(prec85),np.mean(reca85)))
print('*************IOU=0.90***********{:1.3f}\t{:1.3f}'.format(np.mean(prec90),np.mean(reca90)))
print('*************IOU=0.95***********{:1.3f}\t{:1.3f}'.format(np.mean(prec95),np.mean(reca95)))







eval_log_dir=os.path.join('evaluation','log')
if not os.path.isdir(eval_log_dir):
    os.makedirs(eval_log_dir)
fname=model_path.split('/')[-2]
fname=os.path.join(eval_log_dir,fname+'.xlsx')	
writer = pd.ExcelWriter(fname)


data3 = {'type_num' : ['all', np.sum(groundTruth_num), ' ', ' '],
    'IoU' : [0.85, 0.9, 0.95, ' '],
    'Precision' : [np.round(np.mean(prec85), 2), np.round(np.mean(prec90), 2), np.round(np.mean(prec95), 2), ' '],
    'Recall' : [np.round(np.mean(reca85), 2),np.round(np.mean(reca90), 2),np.round(np.mean(reca95), 2), ' ']}
dfs = pd.DataFrame(data=data3)


good_prec85 = 0.0
good_prec90 = 0.0
good_prec95 = 0.0
good_reca85 = 0.0
good_reca90 = 0.0
good_reca95 = 0.0
good_type = []
bad_type = []
good_type_count = 0
for i in range(true_positives_085.shape[0]):
    if groundTruth_num[i] > 0 :
        if 	np.round((true_positives_085[i]+false_positives_085[i]), 2) == 0.0 :	
            prec85 = 0.0	
        else :			
            prec85 = true_positives_085[i]/(true_positives_085[i]+false_positives_085[i])
			
        if 	np.round((true_positives_090[i]+false_positives_090[i]), 2) == 0.0 :	
            prec90 = 0.0	
        else :			
            prec90 = true_positives_090[i]/(true_positives_090[i]+false_positives_090[i])
			
        if 	np.round((true_positives_095[i]+false_positives_095[i]), 2) == 0.0 :	
            prec95 = 0.0	
        else :			
            prec95 = true_positives_095[i]/(true_positives_095[i]+false_positives_095[i])

			
        if 	np.round((true_positives_085[i]+false_negatives_085[i]), 2) == 0.0 :	
            reca85 = 0.0
        else :			
            reca85 = true_positives_085[i]/(true_positives_085[i]+false_negatives_085[i])	

        if 	np.round((true_positives_090[i]+false_negatives_090[i]), 2) == 0.0 :	
            reca90 = 0.0
        else :			
            reca90 = true_positives_090[i]/(true_positives_090[i]+false_negatives_090[i])
			
        if 	np.round((true_positives_095[i]+false_negatives_095[i]), 2) == 0.0 :	
            reca95 = 0.0
        else :			
            reca95 = true_positives_095[i]/(true_positives_095[i]+false_negatives_095[i])

        if prec85 >= 0.8 :
            good_prec85 += prec85 * float(groundTruth_num[i])				
            good_prec90 += prec90 * float(groundTruth_num[i])
            good_prec95 += prec95 * float(groundTruth_num[i])
            good_reca85 += reca85 * float(groundTruth_num[i]) 
            good_reca90 += reca90 * float(groundTruth_num[i]) 
            good_reca95 += reca95 * float(groundTruth_num[i])            
            good_type_count += groundTruth_num[i]
            good_type.append(dataset.bank_id[i])
        else :
            bad_type.append(dataset.bank_id[i])

        data_i = {'type_num' : [dataset.bank_id[i], groundTruth_num[i], ' ', ' '],
            'IoU' : [0.85, 0.9, 0.95, ' '],
            'Precision' : [np.round(prec85, 2), np.round(prec90, 2), np.round(prec95, 2), ' '],
            'Recall' : [np.round(reca85, 2),np.round(reca90, 2),np.round(reca95, 2), ' ']}
        df_i = pd.DataFrame(data=data_i)
        #df_i.to_excel(writer,dataset.bank_id[i])

        dfs=pd.concat([dfs,df_i], ignore_index=True)

        print('{}:{}:num:{}\n{}'.format(i,dataset.bank_id[i],groundTruth_num[i],df_i))
     	
data_i = {'type_num' : ['good', good_type_count, ' ', ' '],
    'IoU' : [0.85, 0.9, 0.95, ' '],
    'Precision' : [np.round(good_prec85/float(good_type_count), 2), np.round(good_prec90/float(good_type_count), 2), np.round(good_prec95/float(good_type_count), 2), ' '],
    'Recall' : [np.round(good_reca85/float(good_type_count), 2),np.round(good_reca90/float(good_type_count), 2),np.round(good_reca95/float(good_type_count), 2), ' ']}
df_i = pd.DataFrame(data=data_i)
dfs=pd.concat([dfs,df_i], ignore_index=True)

data_i = {'type_num' : ['good_type', 'bad_type'],
    'IoU' : [good_type,bad_type],
    'Precision' : [' ',' '],
    'Recall' : [' ',' ']}
df_i = pd.DataFrame(data=data_i)
dfs=pd.concat([dfs,df_i], ignore_index=True)
dfs = dfs[['type_num', 'IoU', 'Precision', 'Recall']]
dfs.to_excel(writer)
print('{}'.format(dfs))
print('good_type:{}'.format(good_type))
print('bad_type:{}'.format(bad_type))
writer.save()




		
