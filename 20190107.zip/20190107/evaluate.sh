#field evaluation
#CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b8120101  --model_path=/data/weightFile/logs/b812010120181122T1245/mask_rcnn_b8120101_0160.h5 --test_dir=readXML/readXML_0103_test | tee evaluation/log/b812010120181122T1245_160.log

CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b0050101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B8120101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b8120101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B0070101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b0070101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b0070301  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b0090101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B0170301  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b0170101  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/

CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B700  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b700  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B004  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b004  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B808  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b808  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=B013  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank=b013  --model_path=/data/weightFile/logs/ --test_dir=readXML/readXML_0103_test | tee evaluation/log/


#page evaluation
CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc_pageL4.py --model_path=/data/weightFile/logs/bank20181212T1212/mask_rcnn_bank_0160.h5 --test_dir=readXML/readXML_0103_test --train_dir=readXML/readXML_1206_zipC | tee page_0103.log


