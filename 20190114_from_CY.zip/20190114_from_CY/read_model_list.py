#-*- coding: cp950 -*-
#-*- coding: utf-8 -*-

import os
import re
import xml.etree.ElementTree as ET
import cv2
import numpy as np
import scipy.misc
import matplotlib.pyplot as plt
from matplotlib.path import Path
import argparse
import zipfile
import shutil
import pandas as pd
import math
	
# Parse command line arguments
parser = argparse.ArgumentParser(description='reading model_list files.')			
parser.add_argument('--model_list', required=False, default='readXML/model_list.txt', help='Directory of logs and files ')
parser.add_argument('--logs', required=False, default='evaluation/log', help='Directory of logs and files ')
parser.add_argument('--today', required=False, default='', help='date ')
parser.add_argument('--readXML_test', required=True, default='None', help='Directory of readXML_test')
parser.add_argument('--evaluate_all', required=False, default=False, help='Directory of readXML_test')
parser.add_argument('--try_Bb', required=False, default=False, help='Directory of readXML_test')

args = parser.parse_args()	
model_list_path=args.model_list           	
if not os.path.isfile(args.model_list):
    raise ValueError('Error:--model_list:model_list files ')

xlsx_path=args.logs           	
if not os.path.isdir(args.logs):
    raise ValueError('Error:--logs:Directory of xlsx files ')

readXML_test_Dir=os.path.join('readXML',args.readXML_test)           	
if not os.path.isdir(readXML_test_Dir):
    raise ValueError('Error:--readXML_test:Directory of readXML_test')

evaluate_all=args.evaluate_all
if evaluate_all=='True':
    print('evaluate all models')

try_Bb=args.try_Bb
if try_Bb=='True':
    print('try Bb all models, sorry.')

print('*****************test print **************************')    


f = open(model_list_path, 'r') 
lines = f.read().splitlines()


model_dic = {}
model_index = 0
for line in lines:
    model_name = line.split('/')[-2]
    if model_name not in model_dic:
        model_dic[model_name] = model_index
        model_index += 1 
#print('model_dic:{}'.format(model_dic))

models = [[] for i in range(len(model_dic))]


for line in lines:
    model_name = line.split('/')[-2]
    models[model_dic[model_name]].append(line)


all_h5 = []
for model_i in models:
    epoch_max = 0 
    for h5_i in model_i:
        h5_name = h5_i.split('/')[-1]
        epoch = h5_name.split('_')[-1]
        epoch = int(epoch.split('.h5')[0])
        if epoch_max == epoch :
            if h5_name.split('_')[0] == 'mask':
                h5 = h5_i

        if epoch_max < epoch :
            epoch_max = epoch
            h5 = h5_i
        
    epoch_max = 0
    all_h5.append(h5) 


done_eval = []
for root_f, dirs_f, files_f in os.walk(xlsx_path):
    for ff in files_f:
        if ('.xlsx' in ff) and not(('summary_model' in ff) or ('bank' in ff)) :
            done_eval.append(ff.split('.xlsx')[0])

if evaluate_all:
    done_eval = []


fname = os.path.join('evaluation/script/evaluate'+args.today+'.sh')
ww = open(fname, 'w')
for h5 in all_h5:
    model_name = h5.split('/')[-2]
    if (model_name not in done_eval) and ('bank' not in model_name) :
        bank = model_name.split('T')[0]
        bank = bank[:-8]
        print('CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank={}  --model_path={} --test_dir={} | tee evaluation/log/{}.log'.format(bank,h5,readXML_test_Dir,model_name),file=ww)
        if try_Bb:
            if bank[0] == 'b':
                bank_Bb = 'B'+bank[1:]
                print('CUDA_VISIBLE_DEVICES=$1 python3 Mask_RCNN/print_all_rotate_LargeD_ctbc7.py train --bank={}  --model_path={} --test_dir={} | tee evaluation/log/{}.log'.format(bank_Bb,h5,readXML_test_Dir,model_name),file=ww)





